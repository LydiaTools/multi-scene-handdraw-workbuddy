from pathlib import Path
import sys,json,hashlib,concurrent.futures,os
import cv2,numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
BACK=ROOT/'vendor/stroke'
sys.path.insert(0,str(BACK/'scripts'))
import render_stream_whiteboard as engine
ASSETS=ROOT/'assets/communication'
OUTPUT=None
FONT=None

def render(output,font):
 global OUTPUT,FONT
 OUTPUT=Path(output);FONT=font
 for d in ['scenes','annotations']:(OUTPUT/d).mkdir(parents=True,exist_ok=True)
 scenes=json.loads((ASSETS/'scenes.json').read_text(encoding='utf-8'))
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(prep,scenes))
 return scenes

def prep(s):
 source=Image.open(ASSETS/f'scene-{s["id"]}.png').convert('RGB');original=np.array(source)[:,:,::-1].copy();draw=ImageDraw.Draw(source)
 if s['id']=='01':
  draw.rounded_rectangle((780,230,1055,340),radius=27,fill='#fff8ec',outline='#984932',width=4)
  draw.line([(800,338),(756,370),(838,340)],fill='#984932',width=4)
  draw.text((819,255),'听我说',font=ImageFont.truetype(FONT,39),fill='#984932')
 if s['id']=='02':
  draw.rounded_rectangle((705,190,1065,315),radius=28,fill='#fff8ec',outline='#984932',width=4)
  draw.line([(1030,312),(1090,345),(1058,300)],fill='#984932',width=4)
  draw.text((795,225),'我自己来',font=ImageFont.truetype(FONT,39),fill='#984932')
 target=np.array(source)[:,:,::-1].copy();h,w=target.shape[:2]
 ann={'sceneId':s['id'],'canvas':{'width':w,'height':h},'sceneDurationMs':round((s['b']-s['a'])*1000),'elements':[]}
 for seq,(name,rect,start,dur) in enumerate(s['regions'],1):
  ann['elements'].append({'id':name,'label':name,'sequence':seq,'narrativeRole':name,'subtitle':name,'type':'prop','region':rect,'reveal':{'direction':'top_to_bottom','startMs':start,'durationMs':dur,'maskPaddingPx':0,'protectedRegions':[]},'handPath':{'start':[rect['x'],rect['y']],'end':[rect['x']+rect['width'],rect['y']+rect['height']],'easing':'easeInOut'}})
 errors,warnings=engine.validate_annotation(ann,(w,h));assert not errors,errors
 p=OUTPUT/'annotations'/f'scene-{s["id"]}.annotation.json';p.write_text(json.dumps(ann,ensure_ascii=False,indent=2),encoding='utf-8')
 cfg=engine.sr.Config(fps=60,cap_long_edge=1920,grid_edge=2,ink_path_mode='skeleton',color_fill='contour-wipe',pause_mode='off',target_hand_height=155,match_bg=False)
 renderer=engine.RegionStreamRenderer(target,ann,cfg,BACK/'assets/drawing-hand.png',False,.35)
 base=cv2.resize(original,(renderer.out_w,renderer.out_h),interpolation=cv2.INTER_AREA)
 renderer.drawn[...]=base.astype(np.float32)
 if s['id']!='01':
  # Preserve the full scene and faces. Current gestures/props begin as light pencil,
  # then the real skeleton pass inks and colors them. No rectangular white wipes.
  for el in ann['elements']:
   allowed=renderer._allowed_mask(el,[]);src=renderer.color_img;hsv=cv2.cvtColor(src,cv2.COLOR_BGR2HSV)
   hh,ss,vv=hsv[:,:,0],hsv[:,:,1],hsv[:,:,2]
   if s['id']=='02' and el['id']=='my_decision':continue
   if s['id']=='02':mask=((hh>=20)&(hh<=38)&(ss>110)&(vv>150)&allowed).astype(np.float32)
   elif s['id']=='03':mask=(((hh<11)|(hh>170))&(ss>80)&(vv>100)&allowed).astype(np.float32)
   elif el['id']=='shared_route':mask=((hh>88)&(hh<125)&(ss>70)&allowed).astype(np.float32)
   else:mask=((hh>35)&(hh<165)&(ss>55)&allowed).astype(np.float32)
   alpha=cv2.GaussianBlur(mask,(9,9),0)*.88
   pencil=np.full_like(renderer.drawn,(232,237,239),dtype=np.float32)
   renderer.drawn=renderer.drawn*(1-alpha[:,:,None])+pencil*alpha[:,:,None]
 output=OUTPUT/'scenes'/f'scene-{s["id"]}.mp4';renderer.render_to(output,ann['sceneDurationMs'])
 record={**s,'annotation':str(p.relative_to(OUTPUT)),'output':str(output.relative_to(OUTPUT)),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'engine':'multi-scene-handdraw / bundled RegionStreamRenderer / skeleton / contour-wipe','paid_calls':0,'background_pan':False,'hand_follow':.35,'initial_complete_context':True,'warnings':warnings}
 output.with_suffix('.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'scene':s['id'],'output':str(output),'sha256':record['sha256']},ensure_ascii=False),flush=True)


from __future__ import annotations
import argparse,sys,os,json,subprocess,shutil,hashlib,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
os.environ['PYTHONUTF8']='1'

def modules_ok(exe):
    p=subprocess.run([str(exe),'-c','import cv2,numpy,PIL,av'],capture_output=True)
    return p.returncode==0

def choose_runtime():
    if modules_ok(sys.executable):return
    candidates=[ROOT/'.venv/Scripts/python.exe',ROOT/'.venv/bin/python',Path.home()/'.codex/skills/multi-scene-handdraw/vendor/srt-whiteboard-animation/.venv/Scripts/python.exe',Path.home()/'.codex/skills/multi-scene-handdraw/vendor/srt-whiteboard-animation/.venv/bin/python']
    for candidate in candidates:
        if candidate.is_file() and modules_ok(candidate):
            raise SystemExit(subprocess.call([str(candidate),'-X','utf8',str(Path(__file__).resolve()),*sys.argv[1:]]))
    print('缺少逐笔绘制依赖。请让Agent在本Skill内创建.venv，运行 pip install -r requirements.txt，再执行原命令。',flush=True)
    raise SystemExit(3)

def find_font():
    paths=[os.environ.get('HANDDRAW_FONT',''),'C:/Windows/Fonts/msyhbd.ttc','C:/Windows/Fonts/msyh.ttc','/System/Library/Fonts/PingFang.ttc','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc']
    for p in paths:
        if p and Path(p).is_file():return p
    raise RuntimeError('未找到中文字体。设置HANDDRAW_FONT为本机有授权的中文字体文件路径。')

def compose(output,font,scenes):
    import av,numpy as np
    from PIL import Image,ImageDraw,ImageFont
    from fractions import Fraction
    output=Path(output);assets=ROOT/'assets/communication'
    cues=json.loads((assets/'captions.json').read_text(encoding='utf-8'))
    overlays=[]
    for j,c in enumerate(cues):
        layer=Image.new('RGBA',(1920,1080),(0,0,0,0));draw=ImageDraw.Draw(layer)
        f=ImageFont.truetype(font,58 if j==0 else 51)
        if j==0:
            text='为什么你越劝，别人越不听？';xy=(70,53);anchor='lt';end=2.15
        else:text=c['text'];xy=(960,1044);anchor='mb';end=c['end']
        draw.text(xy,text,font=f,fill='#263b37',stroke_width=3,stroke_fill='#fff8ed',anchor=anchor)
        box=layer.getbbox();overlays.append((c['start'],end,layer.crop(box),box))
    destination=output/'手绘沟通故事-完整视频.mp4'
    container=av.open(str(destination),'w');vs=container.add_stream('libx264',rate=60)
    vs.width=1920;vs.height=1080;vs.pix_fmt='yuv420p';vs.options={'crf':'17','preset':'fast','threads':'5'}
    audio_stream=container.add_stream('aac',rate=48000);audio_stream.layout='stereo';audio_stream.bit_rate=256000
    index=0
    for scene in scenes:
        n=round(scene['b']*60)-round(scene['a']*60)
        source=av.open(str(output/'scenes'/f'scene-{scene["id"]}.mp4'))
        frames=source.decode(video=0);last=None
        for k in range(n):
            try:last=next(frames).to_image().convert('RGB')
            except StopIteration:
                if last is None:raise RuntimeError('场景没有可解码的视频帧')
            image=last.copy();t=index/60
            for a,b,layer,box in overlays:
                if a<=t<b:image.paste(layer,(box[0],box[1]),layer)
            frame=av.VideoFrame.from_image(image);frame.pts=index;frame.time_base=Fraction(1,60)
            for packet in vs.encode(frame):container.mux(packet)
            index+=1
        source.close();print(f'已合成第{scene["id"]}幕，共{index}帧',flush=True)
    for packet in vs.encode():container.mux(packet)
    decoder=av.open(str(assets/'audio.wav'));resampler=av.AudioResampler(format='fltp',layout='stereo',rate=48000);chunks=[]
    for frame in decoder.decode(audio=0):
        for z in resampler.resample(frame):chunks.append(z.to_ndarray())
    for z in resampler.resample(None):chunks.append(z.to_ndarray())
    samples=np.concatenate(chunks,axis=1).astype('float32');decoder.close()
    target=round(index/60*48000);samples=samples[:,:target]
    if samples.shape[1]<target:samples=np.pad(samples,((0,0),(0,target-samples.shape[1])))
    for at in range(0,target,1024):
        frame=av.AudioFrame.from_ndarray(np.ascontiguousarray(samples[:,at:at+1024]),format='fltp',layout='stereo')
        frame.sample_rate=48000;frame.time_base=Fraction(1,48000);frame.pts=at
        for packet in audio_stream.encode(frame):container.mux(packet)
    for packet in audio_stream.encode():container.mux(packet)
    container.close()
    for name in ['captions.srt','captions.json','scenes.json']:
        shutil.copy2(assets/name,output/name)
    shutil.copy2(ROOT/'references/credits.txt',output/'音乐与素材署名.txt')
    # Actual decode after the mux, not a promised output path.
    check=av.open(str(destination));count=sum(1 for _ in check.decode(video=0));check.close()
    if count!=index:raise RuntimeError(f'解码帧数不符：{count}/{index}')
    return destination,index

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--topic',required=True);parser.add_argument('--output',required=True);parser.add_argument('--compose-only',action='store_true');args=parser.parse_args()
    if not ('越劝' in args.topic and ('不听' in args.topic or '听不' in args.topic)):
        print(json.dumps({'status':'needs_new_story_and_art','topic':args.topic,'next':'由Agent按references/new-topic.md自动规划故事和相应插画，不能复用无关音轨或只换标题。'},ensure_ascii=False));raise SystemExit(2)
    choose_runtime();font=find_font();out=Path(args.output).expanduser().resolve()
    if out==ROOT or ROOT in out.parents:raise RuntimeError('输出请放独立任务目录，不能写进Skill包。')
    out.mkdir(parents=True,exist_ok=True)
    print('主题：为什么你越劝，别人越不听\n故事：劝说 → 抗拒 → 倾听 → 合作\n逐笔渲染真实执行中，使用包内四幅原创插画与已生成音轨。',flush=True)
    if args.compose_only:scenes=json.loads((ROOT/'assets/communication/scenes.json').read_text(encoding='utf-8'))
    else:
        from render_strokes import render
        scenes=render(out,font)
    video,frames=compose(out,font,scenes)
    receipt={'status':'completed','topic':args.topic,'actual_invoker':'record separately from command/UI evidence','skill':'multi-scene-story-workbuddy','renderer':'RegionStreamRenderer skeleton contour-wipe','frames':frames,'fps':60,'width':1920,'height':1080,'duration':frames/60,'audio':'本期已生成的沟通主题旁白、音乐与轻音效，不含私人声音模型','paid_api_calls':0,'file':video.name,'sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'decode':'pass','new_topic_scope':'需要Agent重写故事并生成相应插画与音轨；当前运行复现包内已验证工程'}
    (out/'制作回执.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':'completed','video':str(video),'sha256':receipt['sha256'],'frames':frames},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
